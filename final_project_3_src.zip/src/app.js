import MainLayout from './main_layout.js';

import {
	BrowserRouter as Router,
	Switch,
	Route
} from 'react-router-dom';

function routerStructure() {
  return (
    <Router>
      <div>
	  	<Switch>
          <Route exact path='/'>
            <MainLayout />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

function App() {
    return (
        <div>
	       <div>
	  	        {routerStructure()}
	       </div>
        </div>
    );
}

export default App;
