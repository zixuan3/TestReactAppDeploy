import React from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import './filters.css';

const renderThumb = ({ style, ...props }) => {
  const thumbStyle = {
    borderRadius: 6,
    backgroundColor: '#715947'
  };
  return <div style={{ ...style, ...thumbStyle }} {...props} />;
};

const CustomScrollbars = props => (
  <Scrollbars
    renderThumbHorizontal={renderThumb}
    renderThumbVertical={renderThumb}
    {...props}
  />
);

function bar_text(names, values) {
    let ret = '';
    let has_true = false
    for (let i = 0; i < values.length; i++) {
        if (values[i] === true) {
            if (has_true === false) {
                has_true = true;
                ret = names[i];
            } else {
                return '多选';
            }
        }
    }
    return ret;
}

export default class Filters extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            originality_original: true,
            originality_derivative: true,
            originality_filters: true,
            completion_status_yes: true,
            completion_status_no: true,
            completion_status_filters: true
        }
        this.handleOriginalityChange = this.handleOriginalityChange.bind(this);
        this.handleOriginalityToggle = this.handleOriginalityToggle.bind(this);
        this.handleCompletionStatusChange = this.handleCompletionStatusChange.bind(this);
        this.handleCompletionStatusToggle = this.handleCompletionStatusToggle.bind(this);
    }

    handleOriginalityChange(event) {
        let new_state;
        if (event.target.id === '原创') {
            new_state = !this.state.originality_original;
            this.setState({originality_original: !this.state.originality_original});
        } else if (event.target.id === '衍生') {
            new_state = !this.state.originality_derivative;
            this.setState({originality_derivative: !this.state.originality_derivative});
        }
        console.log('new_state:', new_state);
        if (new_state === true) {
            this.props.onOriginalityChange(['add', event.target.id]);
        } else {
            this.props.onOriginalityChange(['remove', event.target.id]);
        }
    }
    
    handleCompletionStatusChange(event) {
        let new_state;
        if (event.target.id === '连载') {
            new_state = !this.state.completion_status_no;
            this.setState({completion_status_no: !this.state.completion_status_no});
        } else if (event.target.id === '完结') {
            new_state = !this.state.completion_status_yes;
            this.setState({completion_status_yes: !this.state.completion_status_yes});
        }
        console.log('new_state:', new_state);
        if (new_state === true) {
            if (event.target.id === '完结') {
                this.props.onCompletionStatusChange(['add', true]);
            } else {
                this.props.onCompletionStatusChange(['add', false]);
            }
        } else {
            if (event.target.id === '完结') {
                this.props.onCompletionStatusChange(['remove', true]);
            } else {
                this.props.onCompletionStatusChange(['remove', false]);
            }
        }
    }
    
    handleOriginalityToggle(event) {
        //console.log(this.state.originality_filters);
        this.setState({originality_filters: !this.state.originality_filters});  
    }
    
    handleCompletionStatusToggle(event) {
        console.log(this.state.completion_status_filters);
        this.setState({completion_status_filters: !this.state.completion_status_filters});  
    }
    
    render() {
        return (
            <div className='filtersWrapper'>
                <CustomScrollbars>
                <div className="filterWrapper">
                    <div className='barWrapper' onClick={this.handleOriginalityToggle}>
                        <div className='filterBar'>
                            <div className='filterName'>
                                原创性
                            </div>
                            <div className='filterStatus'>
                                {bar_text(['原创','衍生'], 
                                    [this.state.originality_original, this.state.originality_derivative]
                                )}
                            </div>
                        </div>
                    </div>
                    <div className={this.state.originality_filters ? 'buttonsWrapper show' : 'buttonsWrapper hide'}>
                        <div className='buttonWrapper'>
                            <div id="原创" className={this.state.originality_original ? 'clicked button' : 'unclicked button'}
                                onClick={this.handleOriginalityChange}>
                                原创
                            </div>
                        </div>
                        <div className='buttonWrapper'>
                            <div id="衍生" className={this.state.originality_derivative ? 'clicked button' : 'unclicked button'}
                                onClick={this.handleOriginalityChange}>
                                衍生
                            </div>
                        </div>
                    </div>
                </div>
                <div className="filterWrapper">
                    <div className='barWrapper' onClick={this.handleCompletionStatusToggle}>
                        <div className='filterBar'>
                            <div className='filterName'>
                                文章进度
                            </div>
                            <div className='filterStatus'>
                                {bar_text(['完结','连载'], 
                                    [this.state.completion_status_yes, this.state.completion_status_no]
                                )}
                            </div>
                        </div>
                    </div>
                    <div className={this.state.completion_status_filters ? 'buttonsWrapper show' : 'buttonsWrapper hide'}>
                        <div className='buttonWrapper'>
                            <div id="完结" className={this.state.completion_status_yes ? 'clicked button' : 'unclicked button'}
                                onClick={this.handleCompletionStatusChange}>
                                完结
                            </div>
                        </div>
                        <div className='buttonWrapper'>
                            <div id="连载" className={this.state.completion_status_no ? 'clicked button' : 'unclicked button'}
                                onClick={this.handleCompletionStatusChange}>
                                连载
                            </div>
                        </div>
                    </div>
                </div>
                </CustomScrollbars>
            </div>
        )
    }   
}