import React from 'react';
import axios from 'axios';
import Filters from './filters.js';
import Gallery from './gallery.js';
import SearchBar from './search_bar.js';
import './main_layout.css';

export default class MainLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            word_count: 0,
            rating: 0,
            rating_count: 0,
            completion_status: [true, false],
            publication_status: [],
            originality: ['原创', '衍生'],// 原创/衍生
            era: [],// 架空历史/近代现代/幻想未来/古色古香
            type: [],
            // 爱情/武侠/奇幻/仙侠/游戏/传奇/科幻/童话/惊悚/悬疑/剧情/轻小说/古典衍生/东方衍生/西方衍生/其他衍生/儿歌/散文/寓言/童谣/历史故事
            style: [], // 悲剧/正剧/轻松/搞笑/暗黑
            content_labels: []
            // 甜文/爽文/情有独钟/穿书/穿越时空/强强/娱乐圈/重生/豪门世家/快穿/系统/天之骄子/天作之合/种田文/都市情缘/仙侠修真/灵异神怪/无限流/宫廷侯爵/
            // 幻想空间/打脸/业界精英/励志人生/综漫/校园/年代文/女配/星际/女强/破镜重圆/欢喜冤家/文野/年下/竞技/悬疑推理/少年漫/直播/美食/异能/萌宠/咒回/
            // 升级流/现代架空/未来架空/游戏网游/生子/三教九流/江湖恩怨/清穿/基建/恐怖/复仇虐渣/成长/时代奇缘/婚恋/逆袭/青梅竹马/姻缘邂逅/相爱相杀/奇幻魔幻/
            // 西幻/恋爱合约/都市异闻/花季雨季/朝堂之上/机甲/前世今生/末世/科幻/东方玄幻/异想天开/古穿今/历史衍生/异世大陆/玄学/英美衍生/宫斗/时代新风/
            // 近水楼台/随身空间/灵魂转换/制服情缘/虐恋情深/传奇/布衣生活/超级英雄/大冒险/家教/西方罗曼/女扮男装/爱情战争/宅斗/民国旧影/古典名著/武侠/红楼梦
            // 古代幻想/乔装改扮/火影/异闻传说/市井生活/科举/姐弟恋/平局青云/阴差阳错/少女漫/小门小户/网王/日韩/猎人/七五/史诗奇幻/魔法幻情/西方名著/职场/
            // 洪荒/经商/商战/黑篮/齐神/时尚流行/性别转换/边缘恋歌/血族/网红/奇谭/异国奇缘/港台/亡灵异族/七年之痒/聊斋/骑士与剑/封神/美娱/海贼王/死神/乡村爱情/
            // 银魂/网配/圣斗士/婆媳/SD/授权衍生
        };
        this.handleOriginalityChange = this.handleOriginalityChange.bind(this);
        this.handleCompletionStatusChange = this.handleCompletionStatusChange.bind(this);
    }
    
    handleOriginalityChange(originality) {
        let new_originality = this.state.originality;
        if (originality[0] === 'add') {
            if (!this.state.originality.includes(originality[1])) {
                new_originality.push(originality[1]);
            }
        } else if (originality[0] === 'remove') {
            if (this.state.originality.includes(originality[1])) {
                new_originality.splice(new_originality.indexOf(originality[1]), 1);
            }
        }
        //console.log('new_originality:', new_originality);
        this.setState({
            originality: new_originality
        });
    }
    
    handleCompletionStatusChange(completion_status) {
        let new_completion_status = this.state.completion_status;
        if (completion_status[0] === 'add') {
            if (!this.state.completion_status.includes(completion_status[1])) {
                new_completion_status.push(completion_status[1]);
            }
        } else if (completion_status[0] === 'remove') {
            if (this.state.completion_status.includes(completion_status[1])) {
                new_completion_status.splice(new_completion_status.indexOf(completion_status[1]), 1);
            }
        }
        console.log('new_completion_status:', new_completion_status);
        this.setState({
            completion_status: new_completion_status
        });
    }
    
    componentDidMount() {
		axios.get(`http://127.0.0.1:5000/api/all-novels`)
		  .then(res => {
            console.log('res.data:');
            console.log(res.data);
			this.setState({ data: res.data });
		  })
	}
    
    render() {
        return (
            <div id="MainScreen">
                <Filters
                    onOriginalityChange={this.handleOriginalityChange}
                    onCompletionStatusChange={this.handleCompletionStatusChange}
                />
                <SearchBar/>
                <Gallery
                    data={this.state.data}
                    word_count={this.state.word_count}
                    rating={this.state.rating}
                    rating_count={this.state.rating_count}
                    completion_status={this.state.completion_status}
                    publication_status={this.state.publication_status}
                    originality={this.state.originality}
                    era={this.state.era}
                    type={this.state.type}
                    style={this.state.style}
                    content_labels={this.state.content_labels}
                />
            </div>
        )
    }   
}