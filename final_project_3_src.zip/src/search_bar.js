import React from 'react';
import './search_bar.css';

export default class SearchBar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
        }
    }

    render() {
        return (
            <div id="SearchBarWrapper">
                Search Bar to be implemented.
            </div>
        )
    }   
}