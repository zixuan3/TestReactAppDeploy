import React from 'react';
import './gallery.css';
import GalleryDisplay from './gallery_display.js';

export default class Gallery extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            data: this.props.data,
            word_count: this.props.word_count,
            rating: this.props.rating,
            rating_count: this.props.rating_count,
            completion_status: this.props.completion_status,
            publication_status: this.props.publication_status,
            originality: this.props.originality,
            era: this.props.era,
            type: this.props.type,
            style: this.props.style,
            content_labels: this.props.content_labels
        }
    }

    render() {
        //console.log('this.props.data');
        //console.log(this.props.data);
        if ((!this.props.data)||(!this.props.data['Novels'])) {
            return (
                <div id="GalleryWrapper">
                    <GalleryDisplay novels={[]}/>
                </div>
            );
        }
        let novels = this.props.data['Novels'];
        novels = novels.filter(novel => novel['word_count'] >= this.state.word_count);
        novels = novels.filter(novel => {
            //console.log(novel.genre);
            if ('rating' in novel) {
                return (novel['rating'] >= this.state.rating);
            }
            else {
                return true;
            }
        });
        novels = novels.filter(novel => {
            if ('rating_count' in novel) {
                return (novel['rating_count'] >= this.state.rating_count);
            }
            else {
                return true;
            }
        });
        console.log('before:', novels.length);
        novels = novels.filter(novel => {
            if (!this.state.completion_status) {
                return true;
            }
            for (let i = 0; i < this.state.completion_status.length; i++) {
                if (novel['completion_status'] === this.state.completion_status[i]) {
                    return true;
                }
            }
            return false;
        });
        console.log('after:', novels.length);
        novels = novels.filter(novel => {
            if (this.state.publication_status.length === 0) {
                return true;
            }
            if (!novel['publication_status']) {
                return false;
            }
            for (let i = 0; i < this.state.publication_status.length; i++) {
                if (!novel['publication_status'].includes(this.state.publication_status[i])) {
                    return false;
                }
            }
            return true;
        });
        novels = novels.filter(novel => {
            if (!this.state.originality) {
                return true;
            }
            const novel_originality = novel['genre'].split('-')[0];
            for (let i = 0; i < this.state.originality.length; i++) {
                if (novel_originality === this.state.originality[i]) {
                    return true;
                }
            }
            return false;
        });
        novels = novels.filter(novel => {
            if (this.state.era.length === 0) {
                return true;
            }
            const novel_era = novel['genre'].split('-')[2];
            for (let i = 0; i < this.state.era.length; i++) {
                if (novel_era === this.state.era[i]) {
                    return true;
                }
            }
            return false;
        });
        novels = novels.filter(novel => {
            if (this.state.type.length === 0) {
                return true;
            }
            const novel_type = novel['genre'].split('-')[3];
            for (let i = 0; i < this.state.type.length; i++) {
                if (novel_type === this.state.type[i]) {
                    return true;
                }
            }
            return false;
        })
        novels = novels.filter(novel => {
            if (this.state.style.length === 0) {
                return true;
            }
            for (let i = 0; i <= this.state.style.length; i++) {
                if (novel['style'] === this.state.style[i]) {
                    return true;
                }
            }
            return false;
        })
        novels = novels.filter(novel => {
            if (this.state.content_labels.length === 0) {
                return true;
            }
            if (!novel['content_labels']) {
                return false;
            }
            for (let i = 0; i < this.state.content_labels.length; i++) {
                if (!novel['content_labels'].includes(this.state.content_labels[i])) {
                    return false;
                }
            }
            return true;
        });
        //let difference = this.props.data['Novels'].filter(x => !novels.includes(x));
        //console.log('difference');
        //console.log(difference);
        return (
            <div id="GalleryWrapper">
                <GalleryDisplay novels={novels}/>
            </div>
        )
    }   
}